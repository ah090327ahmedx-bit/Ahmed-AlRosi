package com.ahmedalrosi.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val pickFilesRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 48, 36, 48)
            setBackgroundColor(0xFF111111.toInt())
        }

        val title = TextView(this).apply {
            text = "🇷🇺 أحمد الروسي"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWidthWrapHeight())

        val subtitle = TextView(this).apply {
            text = "اختار الصور أو الفيديوهات أو الملفات اللي عاوز تشاركها"
            textSize = 16f
            setTextColor(0xFFDDDDDD.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 28)
        }
        root.addView(subtitle, matchWidthWrapHeight())

        val choose = Button(this).apply {
            text = "اختيار ملفات من الموبايل"
            setOnClickListener { openPicker() }
        }
        root.addView(choose, matchWidthWrapHeight())

        val note = TextView(this).apply {
            text = "\nالنسخة المبدئية: الاختيار يدوي وواضح. ربط تيليجرام يحتاج إعدادًا آمنًا منفصلًا."
            textSize = 13f
            setTextColor(0xFFBBBBBB.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(note, matchWidthWrapHeight())

        setContentView(root)
    }

    private fun matchWidthWrapHeight() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*", "application/pdf", "application/zip", "text/plain"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, pickFilesRequest)
    }

    @Deprecated("Deprecated in Android API; kept for broad starter compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickFilesRequest || resultCode != RESULT_OK || data == null) return

        val count = data.clipData?.itemCount ?: if (data.data != null) 1 else 0
        val message = if (count == 1) "تم اختيار ملف واحد." else "تم اختيار $count ملفات."
        Toast.makeText(this, "$message لم يتم إرسال أي شيء بعد.", Toast.LENGTH_LONG).show()

        // TODO: Add an explicit preview/confirmation screen and a secure backend
        // before uploading user-selected files to Telegram.
    }
}
